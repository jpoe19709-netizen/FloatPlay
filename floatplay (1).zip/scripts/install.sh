
#!/bin/bash
echo "Installing FloatPlay..."
npm install
npm run build
echo "Done."

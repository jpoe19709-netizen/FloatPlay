
# Deployment

## Environments
- development
- preview
- production

Use .env files:
.env.development
.env.production

Vercel auto injects env vars.
